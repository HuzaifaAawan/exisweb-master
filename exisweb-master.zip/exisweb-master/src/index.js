import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import AppLayout from './layouts/AppLayout';         // 🧱 Layout with Header + Menu
import VehicleDetails from './pages/VehicleDetails'; // ✅ Updated to hold captcha+form
import RegistrationNo from './pages/RegistrationNo'; // 🟢 Reserve Number form

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<VehicleDetails />} />         {/* 👈 Home = vehicle form */}
          <Route path="registration" element={<RegistrationNo />} /> {/* ✅ Reserve number */}
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
