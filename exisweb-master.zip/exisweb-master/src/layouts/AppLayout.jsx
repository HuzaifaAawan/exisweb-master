// ✅ All imports at top
import React from 'react';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar'; // Not Menu anymore
import { Outlet } from 'react-router-dom';

// ✅ Functional component starts here
const AppLayout = () => {
  return (
    <div>
      <Header />
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <main style={{ padding: '1rem', flex: 1 }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AppLayout;
