// // src/components/VehicleDetails.jsx
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';

// const VehicleDetails = () => {
//   const [data, setData] = useState(null);

//   useEffect(() => {
//     axios.get('https://58.65.189.226:884/api/vehicle', {
//       withCredentials: true,
//       headers: {
//         Authorization: `Bearer ${localStorage.getItem('token')}`
//       }
//     })
//     .then(response => setData(response.data))
//     .catch(error => console.error('Failed to fetch vehicle data', error));
//   }, []);

//   if (!data) return <p>Loading vehicle details...</p>;

//   return (
//     <div>
//       <h2>Vehicle Details</h2>
//       <pre>{JSON.stringify(data, null, 2)}</pre>
//     </div>
//   );
// };

// export default VehicleDetails;

