import React from "react";
import "./Sidebar.css";

export default function Sidebar() {
  return (
    <div className="Sidebar">
      <span className="sidebar-heading">Public Service Portal</span>

      <div className="sidebar-buttons">
        <label>My Registration Number 1</label>
        <label>My Registration Number 2</label>
        <label>My Registration Number 3</label>
        <label>My Registration Number 4</label>
        <label>My Registration Number 5</label>
        <label>My Registration Number 6</label>
        <label>My Registration Number 7</label>
        <label>My Registration Number 8</label>
      </div>

      <div className="sidebar-footer">
        <div className="profile-box">
          <button className="profile-btn">👤 User Profile</button>
          <button className="logout-btn">🚪 Logout</button>
        </div>
      </div>
    </div>
  );
}
